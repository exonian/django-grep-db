======
Authors
======

``django_grepdb`` is written and maintained by `Michael Blatherwick <https://github.com/exonian>` with support from `Hubbub <https://hubbub.net>`.
